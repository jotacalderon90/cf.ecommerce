'use strict';

const { z } = require('zod');


//Opciones para retorno WebPay (solo token_ws, trio de anula o 4 por timeout)
const onlyTokenWs = z.object({
  token_ws: z.string().min(1),
}).strict();
const onlyTbkFields = z.object({
  TBK_TOKEN: z.string().min(1),
  TBK_ORDEN_COMPRA: z.string().min(1),
  TBK_ID_SESION: z.string().min(1),
}).strict();
const allFourFields = z.object({
  token_ws: z.string().min(1),
  TBK_TOKEN: z.string().min(1),
  TBK_ORDEN_COMPRA: z.string().min(1),
  TBK_ID_SESION: z.string().min(1),
}).strict();

module.exports = {
  
  flow_start: z.object({
    order: z
      .string()
      .regex(/^\d{14}$/, "Debe ser un string numérico de 14 dígitos (YYYYMMDDHHMMSS)")
  }),
  
  flow_end: z.union([allFourFields, onlyTbkFields, onlyTokenWs])
  
};
